Theme Name: ImageHosting
Theme URI: https://github.com/mediabots/Wordpress-Php-Image-Hosting-Script
Author: sohom
Author URI: http://www.MediaBOTS.Net
Description: This theme dedicated to photo/image lover. Now you can upload & share your beautiful moments with the help of this free wordpress theme, which is actually an "Image Hosting Script". Made fully in Php/Wordpress. [Note- No plugin would be required!]
Version: 2.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
Text Domain: ImageHosting
Tags: mediabots,wordpress,cms,framework,php,script,install,hosting,host,image,free,featured,premium,theme,imagehost,image host,image hosting,photo,upload,share,2018,2019,github,demo,video,gallery

